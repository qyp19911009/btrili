//
//  ViewController.h
//  WMZDialog
//
//  Created by wmz on 2019/6/5.
//  Copyright © 2019年 wmz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"

@interface ViewController : UIViewController

@end


