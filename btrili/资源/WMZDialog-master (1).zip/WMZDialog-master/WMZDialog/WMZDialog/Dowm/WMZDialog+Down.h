//
//  WMZDialog+Down.h
//  WMZDialog
//
//  Created by wmz on 2019/6/25.
//  Copyright © 2019年 wmz. All rights reserved.
//

#import "WMZDialog.h"

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialog (Down)
@end

NS_ASSUME_NONNULL_END
