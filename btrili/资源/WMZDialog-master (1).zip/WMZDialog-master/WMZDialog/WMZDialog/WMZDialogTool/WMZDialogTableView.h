//
//  WMZDialogTableView.h
//  WMZDialog
//
//  Created by wmz on 2019/11/6.
//  Copyright © 2019 wmz. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WMZDialogTableView : UITableView
@property(nonatomic,assign)BOOL  wOpenScrollClose;
@property(nonatomic,assign)BOOL  wCardPresent;
@end

@interface WMZDialogButton : UIButton
@end

NS_ASSUME_NONNULL_END
